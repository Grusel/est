#!/bin/sh

while :
do
    node index.js
    sleep 2

done
